document.getElementById('copyCookies').addEventListener('click', function() {
    chrome.cookies.getAll({}, function(cookies) {
        const cookiesJson = JSON.stringify(cookies, null, 2);
        navigator.clipboard.writeText(cookiesJson).then(function() {
            console.log('Copying to clipboard was successful!');
            alert('Cookies copied to clipboard!');
        }, function(err) {
            console.error('Could not copy cookies: ', err);
        });
    });
});
